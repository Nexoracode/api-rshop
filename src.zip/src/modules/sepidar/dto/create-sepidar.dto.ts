export class CreateSepidarDto {}
