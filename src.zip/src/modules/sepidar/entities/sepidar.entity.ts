export class Sepidar {}
