import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { SepidarService } from './sepidar.service';

@Controller('sepidar')
export class SepidarController {
  constructor(private readonly sepidarService: SepidarService) { }

  @Post('register')
  register() {
    return this.sepidarService.register();
  }

  @Post('login')
  login() {
    return this.sepidarService.login();
  }
}
