import { Media } from "src/modules/media/entities/image.entity";
import { IProduct } from "../interfaces/product.interface";
import { IProductResponse } from "../interfaces/product.response";
import { AttributeUnit } from "src/common/enums/attribute.enum";

export class ProductMapper {
    static toResponse(product: IProduct): IProductResponse {
        return {
            id: product.id,
            category: product.category,
            medias: !product.media || product.media.length === 0 ? [] : product.media.map((m) => ({
                id: m.id,
                type: m.type,
                url: m.url,
            })),
            mediaPinned: {
                id: product.mediaPinned.id ?? 0,
                type: product.mediaPinned.type ?? 'image',
                url: product.mediaPinned.url ?? '',
            },
            name: product.name,
            mediaPinnedId: product.mediaPinnedId ?? 0,
            helper: product.helper,
            helperId: product.helperId,
            categoryId: product.categoryId,
            isFeatured: product.isFeatured,
            isLimitedStock: product.isLimitedStock,
            isVisible: product.isVisible,
            orderLimit: product.orderLimit,
            price: product.price,
            stock: product.stock,
            weight: product.weight,
            brand: product.brand,
            brandId: product.brandId,
            weightUnit: product.weightUnit,
            description: product.description,
            discountAmount: product.discountAmount,
            discountPercent: product.discountPercent,
            createdAt: product.createdAt,
            updatedAt: product.updatedAt,
            variants: product.variants.length ? product.variants : null,
            // variants: product.variants as []
            // variants: product.variants.length ? product.variants[0].attributes ? product.variants[0].
            //     attributes.map(attr => ({
            //         groupId: attr.attribute.groupId ?? 0,
            //         group: {
            //             ...attr.attribute.group,
            //             slug: attr.attribute.group?.slug ?? "",
            //             displayOrder: attr.attribute.group?.displayOrder ?? 0,
            //             id: attr.attribute.group?.id ?? 0,
            //             name: attr.attribute.group?.name ?? "",
            //         },
            //         isPublic: attr.attribute.isPublic ?? false,
            //         isVariant: attr.attribute.isVariant ?? false,
            //         name: attr.attribute.name ?? "",
            //         id: attr.attribute.id,
            //         displayOrder: attr.attribute.displayOrder ?? 0,
            //         slug: attr.attribute.slug ?? "",
            //         type: attr.attribute.type,
            //         values: attr.attribute.values ? attr.attribute.values.map(value => ({
            //             id: value.id,
            //             displayOrder: value.displayOrder ?? 0,
            //             displayColor: value.displayColor ?? "",
            //             isActive: value.isActive ?? false,
            //             value: value.value ?? "",
            //             attributeId: value.attributeId ?? 0,
            //         })) : []
            //     })) : [] : [],
        }
    }
}